package id.ranz.antiddos;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Notifikasi serangan ke OP / pemegang permission ranzantiddos.notify.
 *
 * Dipanggil dari thread Netty, jadi tidak menyentuh Bukkit.getOnlinePlayers() maupun scheduler Bukkit
 * (aman di Folia): daftar pemain dijaga sendiri lewat event join/quit, dan pesan dikirim dari thread
 * maintenance setiap detik. Saat serangan besar pesan digabung supaya chat tidak banjir.
 */
public final class AlertManager implements Listener {

    public static final String PREFIX = ChatColor.DARK_GRAY + "[" + ChatColor.RED + "RanzAntiDDoS" + ChatColor.DARK_GRAY + "] ";

    private static final class Alert {
        final String text;      // pesan berwarna
        final String ip;        // jika tidak null -> tombol UNBAN
        Alert(String text, String ip) { this.text = text; this.ip = ip; }
    }

    private final RanzAntiDDoS plugin;
    private final Map<UUID, Player> online = new ConcurrentHashMap<UUID, Player>();
    private final Set<UUID> muted = ConcurrentHashMap.newKeySet();
    private final ConcurrentLinkedQueue<Alert> queue = new ConcurrentLinkedQueue<Alert>();
    private final AtomicInteger queued = new AtomicInteger();
    private volatile long lastOverflowAlert;

    public AlertManager(RanzAntiDDoS plugin) {
        this.plugin = plugin;
    }

    /** Panggil dari main thread (onEnable). */
    public void start() {
        for (Player p : Bukkit.getOnlinePlayers()) online.put(p.getUniqueId(), p);
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        online.put(e.getPlayer().getUniqueId(), e.getPlayer());
        Player p = e.getPlayer();
        if (canReceive(p) && plugin.settings().notifyEnabled) {
            p.sendMessage(PREFIX + ChatColor.GRAY + "Kamu akan menerima peringatan serangan. Matikan: "
                    + ChatColor.YELLOW + "/antiddos notify");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        online.remove(e.getPlayer().getUniqueId());
    }

    private static boolean canReceive(Player p) {
        return p.isOp() || p.hasPermission("ranzantiddos.notify") || p.hasPermission("ranzantiddos.admin");
    }

    /** @return true jika sekarang aktif (tidak di-mute) setelah toggle. */
    public boolean toggle(UUID id) {
        if (muted.remove(id)) return true;
        muted.add(id);
        return false;
    }

    public boolean isMuted(UUID id) {
        return muted.contains(id);
    }

    // ------------------------------------------------------------------ event dari tracker / handler

    public void onBan(String ip, String reason, long durationMs) {
        RanzAntiDDoS.Settings s = plugin.settings();
        if (!s.notifyEnabled || !s.notifyOnBan) return;
        push(new Alert(ChatColor.RED + "ATTACK " + ChatColor.WHITE + "IP " + ChatColor.YELLOW + ip
                + ChatColor.WHITE + " diblokir " + ChatColor.GRAY + "(" + reason + ") "
                + ChatColor.WHITE + "• " + ChatColor.AQUA + formatDuration(durationMs), ip));
    }

    public void onStrike(String ip, String reason, int n, int max) {
        RanzAntiDDoS.Settings s = plugin.settings();
        if (!s.notifyEnabled || !s.notifyOnStrike) return;
        push(new Alert(ChatColor.GOLD + "WARN " + ChatColor.WHITE + "IP " + ChatColor.YELLOW + ip
                + ChatColor.GRAY + " strike " + n + "/" + max + " (" + reason + ")", null));
    }

    /** Slot pra-login global penuh: tanda serangan terdistribusi (banyak IP). Di-cooldown 30 detik. */
    public void onGlobalOverflow() {
        RanzAntiDDoS.Settings s = plugin.settings();
        if (!s.notifyEnabled || !s.notifyOnOverflow) return;
        long now = System.currentTimeMillis();
        if (now - lastOverflowAlert < 30_000L) return;
        lastOverflowAlert = now;
        push(new Alert(ChatColor.DARK_RED + "FLOOD " + ChatColor.WHITE + "Slot pra-login penuh ("
                + s.maxPreLoginGlobal + "), koneksi baru ditolak. Kemungkinan serangan dari banyak IP.", null));
    }

    private void push(Alert a) {
        // batas antrean: cegah memori membengkak saat flood besar
        if (queued.get() > 500) return;
        queued.incrementAndGet();
        queue.add(a);
    }

    // ------------------------------------------------------------------ flush (thread maintenance, 1 dtk)

    public void flush() {
        if (queue.isEmpty()) return;
        int max = Math.max(1, plugin.settings().notifyMaxLinesPerSecond);
        List<Alert> batch = new ArrayList<Alert>();
        Alert a;
        while ((a = queue.poll()) != null) {
            queued.decrementAndGet();
            if (batch.size() < max) batch.add(a);
            else batch.add(null); // placeholder hitung sisa
        }
        int hidden = 0;
        List<Alert> show = new ArrayList<Alert>();
        for (Alert x : batch) {
            if (x == null) hidden++;
            else show.add(x);
        }

        for (Player p : online.values()) {
            try {
                if (!p.isOnline() || muted.contains(p.getUniqueId()) || !canReceive(p)) continue;
                for (Alert x : show) deliver(p, x);
                if (hidden > 0) {
                    p.sendMessage(PREFIX + ChatColor.GRAY + "+" + hidden + " peringatan lain (lihat console / "
                            + ChatColor.YELLOW + "/antiddos list" + ChatColor.GRAY + ")");
                }
            } catch (Throwable ignored) {
                // pemain bisa keluar kapan saja; jangan sampai menghentikan task
            }
        }
    }

    private void deliver(Player p, Alert a) {
        if (a.ip != null) {
            try {
                if (ChatUi.sendButton(p, PREFIX + a.text + " ", ChatColor.GREEN + "[UNBAN]",
                        "Klik untuk mengisi /antiddos unban " + a.ip, "/antiddos unban " + a.ip, false, null)) {
                    return;
                }
            } catch (Throwable t) {
                // API chat tidak ada -> teks biasa
            }
        }
        p.sendMessage(PREFIX + a.text);
    }

    // ------------------------------------------------------------------ util

    public static String formatDuration(long ms) {
        if (ms <= 0) return "permanen";
        long s = ms / 1000L;
        long d = s / 86400L; s %= 86400L;
        long h = s / 3600L; s %= 3600L;
        long m = s / 60L; s %= 60L;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("h ");
        if (h > 0) sb.append(h).append("j ");
        if (m > 0) sb.append(m).append("m ");
        if (sb.length() == 0 || (d == 0 && h == 0 && m == 0)) sb.append(s).append("d");
        return sb.toString().trim();
    }

}
