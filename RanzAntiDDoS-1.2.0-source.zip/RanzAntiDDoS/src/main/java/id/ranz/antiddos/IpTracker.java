package id.ranz.antiddos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

/** Seluruh struktur thread-safe; dipanggil dari thread Netty. Disk I/O hanya di thread async. */
public final class IpTracker {

    public static final class State {
        public final AtomicInteger connections = new AtomicInteger();
        public final AtomicInteger strikes = new AtomicInteger();
        public final AtomicInteger packets = new AtomicInteger();
        public final AtomicLong bytes = new AtomicLong();
        public final AtomicLong windowStart = new AtomicLong();
        public volatile long lastSeen = System.currentTimeMillis();
    }

    /** Data satu ban: kapan kedaluwarsa (Long.MAX_VALUE = permanen), kapan dibuat, dan alasannya. */
    public static final class Ban {
        public final InetAddress ip;
        public final long expires;
        public final long bannedAt;
        public final String reason;

        Ban(InetAddress ip, long expires, long bannedAt, String reason) {
            this.ip = ip;
            this.expires = expires;
            this.bannedAt = bannedAt;
            this.reason = reason;
        }

        public boolean permanent() { return expires == Long.MAX_VALUE; }
    }

    public final AtomicInteger preLoginGlobal = new AtomicInteger();

    private final RanzAntiDDoS plugin;
    private final File file;
    private final ConcurrentHashMap<InetAddress, State> states = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<InetAddress, Ban> blacklist = new ConcurrentHashMap<>();
    private volatile boolean dirty;

    public IpTracker(RanzAntiDDoS plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "blacklist.txt");
    }

    public int blacklistSize() { return blacklist.size(); }
    public int trackedIps() { return states.size(); }

    public State state(InetAddress ip) {
        return states.computeIfAbsent(ip, k -> new State());
    }

    public boolean isIgnored(InetAddress ip) {
        RanzAntiDDoS.Settings s = plugin.settings();
        if (s.whitelist.contains(ip)) return true;
        return s.ignorePrivate && (ip.isLoopbackAddress() || ip.isSiteLocalAddress()
                || ip.isLinkLocalAddress() || ip.isAnyLocalAddress());
    }

    public boolean isBlacklisted(InetAddress ip) {
        Ban b = blacklist.get(ip);
        if (b == null) return false;
        if (!b.permanent() && b.expires < System.currentTimeMillis()) {
            if (blacklist.remove(ip, b)) dirty = true;
            return false;
        }
        return true;
    }

    /** Snapshot ban aktif, terbaru di atas. */
    public List<Ban> bans() {
        long now = System.currentTimeMillis();
        List<Ban> out = new ArrayList<Ban>();
        for (Ban b : blacklist.values()) {
            if (b.permanent() || b.expires >= now) out.add(b);
        }
        Collections.sort(out, new Comparator<Ban>() {
            @Override
            public int compare(Ban a, Ban b) {
                return Long.compare(b.bannedAt, a.bannedAt);
            }
        });
        return out;
    }

    /** durationMs <= 0 -> permanen. */
    public void ban(InetAddress ip, long durationMs, String reason) {
        long now = System.currentTimeMillis();
        long exp = durationMs <= 0 ? Long.MAX_VALUE : now + durationMs;
        String clean = reason == null ? "-" : reason.replace(';', ',').replace('\n', ' ');
        boolean isNew = blacklist.put(ip, new Ban(ip, exp, now, clean)) == null;
        dirty = true;
        if (isNew) {
            if (plugin.settings().logViolations) {
                plugin.getLogger().warning("BLACKLIST " + ip.getHostAddress() + " -> " + clean
                        + (exp == Long.MAX_VALUE ? " [permanen]" : ""));
            }
            AlertManager am = plugin.alerts();
            if (am != null) am.onBan(ip.getHostAddress(), clean, exp == Long.MAX_VALUE ? -1L : durationMs);
        }
    }

    /** @return jumlah strike saat ini; auto-ban saat mencapai batas. */
    public int strike(InetAddress ip, String reason) {
        RanzAntiDDoS.Settings s = plugin.settings();
        State st = state(ip);
        int n = st.strikes.incrementAndGet();
        AlertManager am = plugin.alerts();
        if (am != null && n < s.strikesToBan) am.onStrike(ip.getHostAddress(), reason, n, s.strikesToBan);
        if (n >= s.strikesToBan) {
            st.strikes.set(0);
            ban(ip, s.strikeBanMs, reason + " (strike " + n + "/" + s.strikesToBan + ")");
        }
        return n;
    }

    /** Geser window 1 detik (best-effort, race kecil tidak masalah). */
    public void roll(State st, long now) {
        long ws = st.windowStart.get();
        if (now - ws >= 1000L && st.windowStart.compareAndSet(ws, now)) {
            st.packets.set(0);
            st.bytes.set(0);
        }
    }

    /** Hanya menerima IP literal (tanpa DNS lookup) supaya aman dipanggil dari command. */
    public static InetAddress parseIp(String s) {
        if (s == null) return null;
        s = s.trim();
        if (!(s.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}") || (s.indexOf(':') >= 0 && s.matches("[0-9a-fA-F:.%]+")))) {
            return null;
        }
        try {
            return InetAddress.getByName(s);
        } catch (Exception e) {
            return null;
        }
    }

    public boolean unban(String ipLiteral) {
        InetAddress ip = parseIp(ipLiteral);
        if (ip == null) return false;
        State st = states.get(ip);
        if (st != null) st.strikes.set(0);
        boolean removed = blacklist.remove(ip) != null;
        if (removed) dirty = true;
        return removed;
    }

    /** @return jumlah IP yang di-unban. */
    public int unbanAll() {
        int n = blacklist.size();
        blacklist.clear();
        for (State st : states.values()) st.strikes.set(0);
        if (n > 0) dirty = true;
        return n;
    }

    // ------------------------------------------------------------------ maintenance & persistence

    public void maintenance() {
        long now = System.currentTimeMillis();
        if (blacklist.entrySet().removeIf(e -> !e.getValue().permanent() && e.getValue().expires < now)) dirty = true;
        states.entrySet().removeIf(e -> e.getValue().connections.get() <= 0 && now - e.getValue().lastSeen > 600_000L);
        if (dirty) save();
    }

    public synchronized void save() {
        try {
            plugin.getDataFolder().mkdirs();
            dirty = false;
            try (BufferedWriter w = Files.newBufferedWriter(file.toPath(), StandardCharsets.UTF_8)) {
                // format: ip;expires;bannedAt;reason
                for (Map.Entry<InetAddress, Ban> e : blacklist.entrySet()) {
                    Ban b = e.getValue();
                    w.write(e.getKey().getHostAddress() + ";" + b.expires + ";" + b.bannedAt + ";" + b.reason);
                    w.newLine();
                }
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Gagal menyimpan blacklist", ex);
        }
    }

    public void load() {
        if (!file.exists()) return;
        long now = System.currentTimeMillis();
        try (BufferedReader r = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split(";", 4);
                if (p.length < 2) continue;
                try {
                    long exp = Long.parseLong(p[1].trim());
                    if (exp != Long.MAX_VALUE && exp < now) continue;
                    InetAddress ip = parseIp(p[0]);
                    if (ip == null) continue;
                    // p.length == 2: format lama (tanpa alasan/waktu)
                    long at = p.length >= 3 ? Long.parseLong(p[2].trim()) : now;
                    String reason = p.length >= 4 ? p[3] : "(ban lama)";
                    blacklist.put(ip, new Ban(ip, exp, at, reason));
                } catch (Exception ignored) {
                }
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Gagal membaca blacklist", ex);
        }
    }
}
