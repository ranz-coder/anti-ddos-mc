package id.ranz.antiddos;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * Kompatibel: Spigot/Paper 1.8 s/d 1.21.x dan 26.x (bytecode Java 8, tanpa NMS langsung,
 * tanpa Bukkit scheduler -> juga aman di Folia).
 */
public final class RanzAntiDDoS extends JavaPlugin {

    /** Snapshot config immutable; aman dibaca dari thread Netty mana pun. */
    public static final class Settings {
        public final boolean enabled;
        public final int maxConnectionsPerIp;
        public final int maxPreLoginGlobal;
        public final int maxPacketsPerSecond;
        public final int hardPacketsPerSecond;
        public final long maxBytesPerSecond;
        public final int maxPacketSize;
        public final int maxHandshakeSize;
        public final int maxLoginSize;
        public final long firstPacketTimeoutMs;
        public final long frameTimeoutMs;
        public final long preLoginTotalTimeoutMs;
        public final int strikesToBan;
        public final long strikeBanMs;
        public final long oversizeBanMs;
        public final boolean ignorePrivate;
        public final boolean logViolations;
        public final boolean notifyEnabled;
        public final boolean notifyOnBan;
        public final boolean notifyOnStrike;
        public final boolean notifyOnOverflow;
        public final int notifyMaxLinesPerSecond;
        public final Set<InetAddress> whitelist;

        Settings(FileConfiguration c) {
            enabled = c.getBoolean("enabled", true);
            maxConnectionsPerIp = Math.max(1, c.getInt("connections.max-per-ip", 3));
            maxPreLoginGlobal = Math.max(10, c.getInt("connections.max-prelogin-global", 400));
            maxPacketsPerSecond = Math.max(1, c.getInt("rate-limit.packets-per-second", 50));
            hardPacketsPerSecond = Math.max(maxPacketsPerSecond, c.getInt("rate-limit.hard-limit-per-second", 400));
            maxBytesPerSecond = Math.max(1024L, c.getLong("rate-limit.bytes-per-second", 1_048_576L));
            maxPacketSize = Math.max(64, c.getInt("packet-size.max-packet-size", 2_097_152));
            maxHandshakeSize = Math.max(64, c.getInt("packet-size.max-handshake-size", 8192));
            maxLoginSize = Math.max(64, c.getInt("packet-size.max-login-size", 4096));
            firstPacketTimeoutMs = Math.max(500L, c.getLong("timeouts.first-packet-ms", 3000L));
            frameTimeoutMs = Math.max(500L, c.getLong("timeouts.frame-complete-ms", 3000L));
            preLoginTotalTimeoutMs = Math.max(2000L, c.getLong("timeouts.prelogin-total-ms", 20000L));
            strikesToBan = Math.max(1, c.getInt("blacklist.strikes-to-ban", 3));
            strikeBanMs = Math.max(0L, c.getLong("blacklist.strike-ban-minutes", 60L)) * 60_000L;
            oversizeBanMs = Math.max(0L, c.getLong("blacklist.oversize-ban-minutes", 0L)) * 60_000L;
            logViolations = c.getBoolean("blacklist.log-violations", true);
            notifyEnabled = c.getBoolean("notifications.enabled", true);
            notifyOnBan = c.getBoolean("notifications.on-ban", true);
            notifyOnStrike = c.getBoolean("notifications.on-strike", false);
            notifyOnOverflow = c.getBoolean("notifications.on-prelogin-overflow", true);
            notifyMaxLinesPerSecond = Math.max(1, c.getInt("notifications.max-lines-per-second", 3));
            ignorePrivate = c.getBoolean("whitelist.ignore-private-addresses", true);
            Set<InetAddress> wl = new HashSet<InetAddress>();
            for (String s : c.getStringList("whitelist.ips")) {
                try {
                    wl.add(InetAddress.getByName(s.trim()));
                } catch (Exception ignored) {
                }
            }
            whitelist = wl;
        }
    }

    private volatile Settings settings;
    private volatile boolean active;
    private IpTracker tracker;
    private volatile AlertManager alerts;
    private NettyPipelineInjector injector;
    private ScheduledExecutorService scheduler;

    public Settings settings() {
        return settings;
    }

    /** Bisa null sebelum onEnable selesai / setelah onDisable. */
    public AlertManager alerts() {
        return alerts;
    }

    public boolean isActive() {
        return active;
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(getConfig());
        tracker = new IpTracker(this);
        tracker.load();
        alerts = new AlertManager(this);
        alerts.start();
        injector = new NettyPipelineInjector(this, tracker);
        active = true;

        // Thread sendiri (daemon): tidak menyentuh main thread & tidak bergantung scheduler Bukkit/Folia.
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "RanzAntiDDoS-Maint");
            t.setDaemon(true);
            return t;
        });

        if (!injector.inject()) {
            // Listener TCP kadang belum siap; coba lagi beberapa kali.
            scheduler.schedule(() -> retryInject(1), 2, TimeUnit.SECONDS);
        }

        scheduler.scheduleWithFixedDelay(() -> {
            try {
                tracker.maintenance();
            } catch (Throwable t) {
                getLogger().log(Level.WARNING, "maintenance error", t);
            }
        }, 30, 30, TimeUnit.SECONDS);

        scheduler.scheduleWithFixedDelay(() -> {
            try {
                alerts.flush();
            } catch (Throwable t) {
                getLogger().log(Level.WARNING, "alert error", t);
            }
        }, 1, 1, TimeUnit.SECONDS);
    }

    private void retryInject(int attempt) {
        if (!active || injector.inject()) return;
        if (attempt >= 5) {
            getLogger().severe("Gagal inject ke Netty pipeline! Server TIDAK dilindungi. Penyebab: " + injector.lastError());
            return;
        }
        scheduler.schedule(() -> retryInject(attempt + 1), 3, TimeUnit.SECONDS);
    }

    @Override
    public void onDisable() {
        active = false;
        alerts = null;
        if (scheduler != null) scheduler.shutdownNow();
        if (injector != null) injector.uninject();
        if (tracker != null) tracker.save();
    }

    // ------------------------------------------------------------------ command

    private static final int PAGE_SIZE = 8;
    private static final String P = AlertManager.PREFIX;

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            help(s);
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "status":
                s.sendMessage(P + ChatColor.GRAY + "Status");
                line(s, "Proteksi", active && settings.enabled ? ChatColor.GREEN + "AKTIF" : ChatColor.RED + "MATI");
                line(s, "IP terblokir", String.valueOf(tracker.blacklistSize()));
                line(s, "IP terpantau", String.valueOf(tracker.trackedIps()));
                line(s, "Pra-login", tracker.preLoginGlobal.get() + "/" + settings.maxPreLoginGlobal);
                line(s, "Channel terpasang", String.valueOf(injector.injectedCount()));
                break;
            case "list":
            case "bans":
                showBans(s, a.length >= 2 ? parsePage(a[1]) : 1, false);
                break;
            case "unban":
            case "pardon":
                if (a.length < 2) {
                    // tanpa argumen: tampilkan IP yang terban beserta tombol [UNBAN]
                    showBans(s, 1, true);
                } else if (a[1].equalsIgnoreCase("all")) {
                    int n = tracker.unbanAll();
                    s.sendMessage(P + ChatColor.GREEN + n + " IP di-unban.");
                    getLogger().info(s.getName() + " unban semua (" + n + " IP)");
                } else if (a[1].equalsIgnoreCase("page") && a.length >= 3) {
                    showBans(s, parsePage(a[2]), true);
                } else {
                    InetAddress ip = IpTracker.parseIp(a[1]);
                    if (ip == null) {
                        s.sendMessage(P + ChatColor.RED + "Bukan alamat IP yang valid: " + ChatColor.YELLOW + a[1]);
                    } else if (tracker.unban(a[1])) {
                        s.sendMessage(P + ChatColor.GREEN + "IP " + ChatColor.YELLOW + ip.getHostAddress()
                                + ChatColor.GREEN + " berhasil di-unban.");
                        getLogger().info(s.getName() + " unban " + ip.getHostAddress());
                    } else {
                        s.sendMessage(P + ChatColor.RED + "IP " + ChatColor.YELLOW + ip.getHostAddress()
                                + ChatColor.RED + " tidak ada di blacklist.");
                    }
                }
                break;
            case "notify":
                if (!(s instanceof Player)) {
                    s.sendMessage(P + ChatColor.GRAY + "Console selalu menerima log.");
                } else {
                    boolean on = alerts.toggle(((Player) s).getUniqueId());
                    s.sendMessage(P + "Notifikasi serangan: " + (on ? ChatColor.GREEN + "ON" : ChatColor.RED + "OFF")
                            + ChatColor.GRAY + " (sampai server restart)");
                }
                break;
            case "reload":
                reloadConfig();
                settings = new Settings(getConfig());
                s.sendMessage(P + ChatColor.GREEN + "Config direload.");
                break;
            default:
                help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage(P + ChatColor.GRAY + "Perintah");
        s.sendMessage(ChatColor.YELLOW + " /antiddos status " + ChatColor.GRAY + "- ringkasan proteksi");
        s.sendMessage(ChatColor.YELLOW + " /antiddos list [hal] " + ChatColor.GRAY + "- daftar IP terblokir");
        s.sendMessage(ChatColor.YELLOW + " /antiddos unban " + ChatColor.GRAY + "- pilih IP terblokir (klik)");
        s.sendMessage(ChatColor.YELLOW + " /antiddos unban <ip|all> " + ChatColor.GRAY + "- buka blokir");
        s.sendMessage(ChatColor.YELLOW + " /antiddos notify " + ChatColor.GRAY + "- hidup/matikan peringatan");
        s.sendMessage(ChatColor.YELLOW + " /antiddos reload " + ChatColor.GRAY + "- muat ulang config");
    }

    private static void line(CommandSender s, String k, String v) {
        s.sendMessage(ChatColor.GRAY + " " + k + ": " + ChatColor.WHITE + v);
    }

    private static int parsePage(String x) {
        try {
            return Math.max(1, Integer.parseInt(x));
        } catch (NumberFormatException e) {
            return 1;
        }
    }

    private void showBans(CommandSender s, int page, boolean unbanMode) {
        List<IpTracker.Ban> all = tracker.bans();
        if (all.isEmpty()) {
            s.sendMessage(P + ChatColor.GREEN + "Tidak ada IP yang sedang terblokir.");
            return;
        }
        int pages = (all.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        if (page > pages) page = pages;
        s.sendMessage(P + ChatColor.WHITE + "IP terblokir: " + ChatColor.YELLOW + all.size()
                + ChatColor.GRAY + "  (hal " + page + "/" + pages + ")");
        long now = System.currentTimeMillis();
        for (int i = (page - 1) * PAGE_SIZE; i < Math.min(all.size(), page * PAGE_SIZE); i++) {
            IpTracker.Ban b = all.get(i);
            String ip = b.ip.getHostAddress();
            String left = b.permanent() ? "permanen" : AlertManager.formatDuration(b.expires - now) + " lagi";
            String text = ChatColor.DARK_GRAY + " " + (i + 1) + ". " + ChatColor.YELLOW + ip
                    + ChatColor.GRAY + " • " + ChatColor.AQUA + left
                    + ChatColor.GRAY + " • " + trim(b.reason, 48) + " ";
            boolean sent = false;
            try {
                sent = ChatUi.sendButton(s, text, ChatColor.GREEN + "[UNBAN]",
                        "Klik untuk unban " + ip, "/antiddos unban " + ip, true, null);
            } catch (Throwable t) {
                // tanpa API chat
            }
            if (!sent) s.sendMessage(text);
        }
        String nav = unbanMode ? "/antiddos unban page " : "/antiddos list ";
        if (pages > 1) s.sendMessage(ChatColor.GRAY + " Halaman lain: " + ChatColor.YELLOW + nav + "<1-" + pages + ">");
        s.sendMessage(ChatColor.GRAY + " Unban manual: " + ChatColor.YELLOW + "/antiddos unban <ip>"
                + ChatColor.GRAY + "  |  semua: " + ChatColor.YELLOW + "/antiddos unban all");
    }

    private static String trim(String r, int max) {
        if (r == null) return "-";
        return r.length() <= max ? r : r.substring(0, max - 1) + "…";
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        List<String> out = new ArrayList<String>();
        if (a.length == 1) {
            for (String x : new String[]{"status", "list", "unban", "notify", "reload"}) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("unban") || a[0].equalsIgnoreCase("pardon"))) {
            String pre = a[1].toLowerCase(Locale.ROOT);
            if ("all".startsWith(pre)) out.add("all");
            for (IpTracker.Ban b : tracker.bans()) {
                String ip = b.ip.getHostAddress();
                if (ip.startsWith(pre)) out.add(ip);
            }
        }
        return out;
    }
}
