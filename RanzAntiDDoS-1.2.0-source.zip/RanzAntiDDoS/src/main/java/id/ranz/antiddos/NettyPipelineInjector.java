package id.ranz.antiddos;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.socket.ServerSocketChannel;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Inject ke server channel Minecraft (ServerBootstrap). Setiap koneksi baru ("child channel")
 * mendapat PacketGuardHandler di posisi PALING DEPAN pipeline, sebelum splitter/decoder vanilla,
 * jadi payload raksasa ditolak sebelum dialokasikan oleh Netty/Minecraft.
 *
 * Tidak ada referensi class NMS di bytecode. Semua pencarian field/method memakai TIPE
 * (bukan nama), jadi tahan terhadap perbedaan mapping dan versi (1.8 s/d 1.21.x dan 26.x).
 */
public final class NettyPipelineInjector {

    private static final String INTERCEPTOR = "ranz_interceptor";
    public static final String GUARD = "ranz_guard";

    private final RanzAntiDDoS plugin;
    private final IpTracker tracker;
    private final List<Channel> injected = new CopyOnWriteArrayList<Channel>();
    private final Interceptor interceptor = new Interceptor();
    private volatile String lastError = "-";

    public NettyPipelineInjector(RanzAntiDDoS plugin, IpTracker tracker) {
        this.plugin = plugin;
        this.tracker = tracker;
    }

    public int injectedCount() {
        return injected.size();
    }

    public String lastError() {
        return lastError;
    }

    /** @return true jika minimal satu server channel sudah ter-inject. */
    public boolean inject() {
        try {
            for (ChannelFuture f : findServerChannels()) {
                Channel ch = f.channel();
                if (!(ch instanceof ServerSocketChannel)) continue; // lewati LocalServerChannel
                if (ch.pipeline().get(INTERCEPTOR) != null) continue;
                ch.pipeline().addFirst(INTERCEPTOR, interceptor);
                injected.add(ch);
                plugin.getLogger().info("Terpasang di " + ch.localAddress());
            }
            if (injected.isEmpty()) {
                lastError = "tidak ada server channel TCP yang aktif";
                return false;
            }
            return true;
        } catch (Throwable t) {
            lastError = String.valueOf(t);
            return false;
        }
    }

    public void uninject() {
        for (Channel ch : injected) {
            try {
                if (ch.pipeline().get(INTERCEPTOR) != null) ch.pipeline().remove(INTERCEPTOR);
            } catch (Throwable ignored) {
            }
        }
        injected.clear();
    }

    // ------------------------------------------------------------------ reflection

    private List<ChannelFuture> findServerChannels() throws Exception {
        Object mcServer = minecraftServer();
        Object connection = findConnection(mcServer);
        if (connection == null) throw new IllegalStateException("ServerConnection tidak ditemukan");

        for (Class<?> c = connection.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (!isChannelFutureList(f)) continue;
                f.setAccessible(true);
                List<?> raw = (List<?>) f.get(connection);
                if (raw == null) continue;
                List<ChannelFuture> out = new ArrayList<ChannelFuture>();
                synchronized (raw) { // list vanilla = Collections.synchronizedList
                    for (Object o : raw) {
                        if (o instanceof ChannelFuture) out.add((ChannelFuture) o);
                    }
                }
                return out;
            }
        }
        throw new IllegalStateException("List<ChannelFuture> tidak ditemukan");
    }

    /** CraftServer#getServer() ada di semua versi; fallback: cari field bertipe MinecraftServer. */
    private Object minecraftServer() throws Exception {
        Object server = plugin.getServer();
        try {
            return server.getClass().getMethod("getServer").invoke(server);
        } catch (NoSuchMethodException e) {
            for (Class<?> c = server.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (hasSuperNamed(f.getType(), "MinecraftServer")) {
                        f.setAccessible(true);
                        Object v = f.get(server);
                        if (v != null) return v;
                    }
                }
            }
            throw e;
        }
    }

    private static boolean hasSuperNamed(Class<?> t, String simpleName) {
        for (Class<?> c = t; c != null; c = c.getSuperclass()) {
            if (c.getSimpleName().equals(simpleName)) return true;
        }
        return false;
    }

    /** Cari objek ServerConnection lewat tipe field, lalu lewat method tanpa parameter. */
    private Object findConnection(Object mc) throws Exception {
        for (Class<?> c = mc.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                Class<?> t = f.getType();
                if (t.isPrimitive() || !t.getName().startsWith("net.minecraft.")) continue;
                if (!declaresChannelFutureList(t)) continue;
                f.setAccessible(true);
                Object v = f.get(mc);
                if (v != null) return v;
            }
        }
        for (Class<?> c = mc.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.getParameterTypes().length != 0 || Modifier.isStatic(m.getModifiers())) continue;
                Class<?> t = m.getReturnType();
                if (t.isPrimitive() || !t.getName().startsWith("net.minecraft.")) continue;
                if (!declaresChannelFutureList(t)) continue;
                m.setAccessible(true);
                Object v = m.invoke(mc);
                if (v != null) return v;
            }
        }
        return null;
    }

    private static boolean declaresChannelFutureList(Class<?> t) {
        for (Class<?> c = t; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (isChannelFutureList(f)) return true;
            }
        }
        return false;
    }

    private static boolean isChannelFutureList(Field f) {
        if (!List.class.isAssignableFrom(f.getType())) return false;
        Type g = f.getGenericType();
        if (!(g instanceof ParameterizedType)) return false;
        Type[] args = ((ParameterizedType) g).getActualTypeArguments();
        return args.length == 1 && args[0].equals(ChannelFuture.class);
    }

    // ------------------------------------------------------------------ handler

    /** Dipasang di server channel; menerima setiap child channel baru sebelum diregistrasi. */
    @ChannelHandler.Sharable
    private final class Interceptor extends ChannelInboundHandlerAdapter {
        @Override
        public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
            if (msg instanceof Channel && plugin.isActive()) {
                try {
                    // addFirst di channel yang belum teregistrasi: aman, callback ditunda.
                    // Hasilnya guard berada SEBELUM handler vanilla yang ditambah ServerBootstrapAcceptor.
                    ((Channel) msg).pipeline().addFirst(GUARD, new PacketGuardHandler(plugin, tracker));
                } catch (Throwable ignored) {
                    // jangan pernah mengganggu accept koneksi sah
                }
            }
            ctx.fireChannelRead(msg);
        }
    }
}
