package id.ranz.antiddos;

import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Pesan chat dengan tombol klik. Dipisah ke class sendiri: jika server tidak punya API chat
 * (CraftBukkit murni), pemanggil menangkap NoClassDefFoundError dan jatuh ke teks biasa.
 */
final class ChatUi {

    private ChatUi() {
    }

    /** Kirim "prefix [label] suffix". @return false jika sender bukan pemain (pakai teks biasa). */
    static boolean sendButton(CommandSender to, String prefix, String label, String hover,
                              String command, boolean run, String suffix) {
        if (!(to instanceof Player)) return false;
        TextComponent line = new TextComponent("");
        for (BaseComponent c : TextComponent.fromLegacyText(prefix)) line.addExtra(c);
        TextComponent btn = new TextComponent(label);
        btn.setClickEvent(new ClickEvent(run ? ClickEvent.Action.RUN_COMMAND : ClickEvent.Action.SUGGEST_COMMAND, command));
        btn.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new ComponentBuilder(hover).create()));
        line.addExtra(btn);
        if (suffix != null && !suffix.isEmpty()) {
            for (BaseComponent c : TextComponent.fromLegacyText(suffix)) line.addExtra(c);
        }
        ((Player) to).spigot().sendMessage(line);
        return true;
    }
}
