package id.ranz.antiddos;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.concurrent.ScheduledFuture;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.concurrent.TimeUnit;

/**
 * Satu instance per koneksi. SEMUA state hanya disentuh dari event loop channel -> tanpa lock,
 * tanpa main thread.
 *
 * Fungsi:
 *  - PacketSizeLimiter: parse VarInt frame length mentah dari 3 frame pertama (handshake, login/status,
 *    frame ke-3) TANPA membaca payload. Setelah itu stream bisa terenkripsi, jadi parsing dihentikan.
 *  - Read-timeout anti slowloris (watchdog 500ms, hanya selama fase pra-login).
 *  - Limit koneksi per IP + rate limit (backpressure, bukan drop byte).
 */
public final class PacketGuardHandler extends ChannelInboundHandlerAdapter {

    private static final int MAX_PARSED_FRAMES = 3;

    private final RanzAntiDDoS plugin;
    private final IpTracker tracker;
    private RanzAntiDDoS.Settings cfg;

    private InetAddress ip;
    private IpTracker.State ipState;

    private boolean counted, preLoginCounted, activeForwarded, closed, throttled;
    private boolean bypass;
    private boolean parsing = true;

    private int frameIndex, frameLen, frameRemaining, lenBytes;
    private long lenAccum;
    private long connectedMs, frameStartMs, lastProgressMs;
    private ScheduledFuture<?> watchdog;

    public PacketGuardHandler(RanzAntiDDoS plugin, IpTracker tracker) {
        this.plugin = plugin;
        this.tracker = tracker;
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void channelActive(final ChannelHandlerContext ctx) throws Exception {
        cfg = plugin.settings();
        SocketAddress sa = ctx.channel().remoteAddress();
        InetAddress addr = (sa instanceof InetSocketAddress) ? ((InetSocketAddress) sa).getAddress() : null;

        if (addr == null || !plugin.isActive() || !cfg.enabled || tracker.isIgnored(addr)) {
            bypass = true;
            parsing = false;
            forwardActive(ctx);
            return;
        }
        ip = addr;

        // Blacklist: drop langsung di channelActive, vanilla tidak pernah tahu koneksi ini ada.
        if (tracker.isBlacklisted(ip)) {
            kill(ctx);
            return;
        }

        long now = System.currentTimeMillis();
        connectedMs = lastProgressMs = now;
        ipState = tracker.state(ip);
        ipState.lastSeen = now;

        counted = true;
        int c = ipState.connections.incrementAndGet();
        if (c > cfg.maxConnectionsPerIp) {
            tracker.strike(ip, "terlalu banyak koneksi simultan (" + c + ")");
            kill(ctx);
            return;
        }

        preLoginCounted = true;
        if (tracker.preLoginGlobal.incrementAndGet() > cfg.maxPreLoginGlobal) {
            AlertManager am = plugin.alerts();
            if (am != null) am.onGlobalOverflow();
            kill(ctx); // proteksi RAM global; tidak menghukum IP
            return;
        }

        watchdog = ctx.executor().scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                watchdogTick(ctx);
            }
        }, 500, 500, TimeUnit.MILLISECONDS);
        forwardActive(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        closed = true;
        cancelWatchdog();
        if (counted) {
            ipState.connections.decrementAndGet();
            counted = false;
        }
        if (preLoginCounted) {
            tracker.preLoginGlobal.decrementAndGet();
            preLoginCounted = false;
        }
        // Jangan teruskan ke vanilla jika channelActive tidak pernah diteruskan (hindari NPE di Connection).
        if (activeForwarded) ctx.fireChannelInactive();
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        if (closed && !activeForwarded) return;
        ctx.fireExceptionCaught(cause);
    }

    // ------------------------------------------------------------------ data path

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (closed) {
            ReferenceCountUtil.release(msg);
            return;
        }
        if (bypass || !plugin.isActive() || !(msg instanceof ByteBuf)) {
            ctx.fireChannelRead(msg);
            return;
        }
        ByteBuf buf = (ByteBuf) msg;

        long now = System.currentTimeMillis();
        int readable = buf.readableBytes();

        // ---- 1. Budget per-IP (agregat semua koneksi dari IP yang sama)
        ipState.lastSeen = now;
        tracker.roll(ipState, now);
        int pk = ipState.packets.incrementAndGet();
        long by = ipState.bytes.addAndGet(readable);

        if (by > cfg.maxBytesPerSecond) {
            ReferenceCountUtil.release(msg);
            strikeAndKill(ctx, "bandwidth flood (" + by + " B/s)");
            return;
        }
        if (pk > cfg.hardPacketsPerSecond) {
            ReferenceCountUtil.release(msg);
            strikeAndKill(ctx, "packet flood (" + pk + " pkt/s)");
            return;
        }
        if (pk > cfg.maxPacketsPerSecond) {
            throttle(ctx, now); // data TETAP diteruskan; hanya pembacaan berikutnya ditahan
        }

        // ---- 2. Inspeksi frame (hanya fase awal)
        if (parsing && !inspect(ctx, buf, now)) {
            ReferenceCountUtil.release(msg);
            return;
        }

        ctx.fireChannelRead(msg);
    }

    /** @return false jika pelanggaran terdeteksi (channel sudah ditutup). */
    private boolean inspect(ChannelHandlerContext ctx, ByteBuf buf, long now) {
        int i = buf.readerIndex();
        final int end = buf.writerIndex();

        while (i < end && parsing) {
            if (frameRemaining > 0) {
                // byte pertama payload frame #0 = packet id Handshake, harus 0x00.
                // HTTP ("POST"), TLS (0x16 0x03..), dsb. gugur di sini.
                if (frameIndex == 0 && frameRemaining == frameLen && buf.getByte(i) != 0x00) {
                    return strikeAndKill(ctx, "bukan trafik Minecraft (packet id pertama != 0x00)");
                }
                int take = Math.min(frameRemaining, end - i);
                i += take;
                frameRemaining -= take;
                if (frameRemaining == 0) frameDone(now);
                continue;
            }

            byte b = buf.getByte(i++); // peek absolut: payload TIDAK dikonsumsi/dialokasikan
            if (lenBytes == 0) {
                if (frameIndex == 0 && (b & 0xFF) == 0xFE) { // legacy server-list ping
                    stopParsing();
                    return true;
                }
                frameStartMs = now;
            }
            lenAccum |= (long) (b & 0x7F) << (7 * lenBytes);
            lenBytes++;

            if ((b & 0x80) != 0) {
                if (lenBytes >= 4) { // >= 2^28, pasti > batas
                    return banAndKill(ctx, "VarInt panjang frame tidak wajar");
                }
                continue;
            }

            long len = lenAccum;
            lenAccum = 0;
            lenBytes = 0;

            if (len > cfg.maxPacketSize) {
                return banAndKill(ctx, "paket " + len + " byte > " + cfg.maxPacketSize + " (OOM attack)");
            }
            int stageLimit = (frameIndex == 0) ? cfg.maxHandshakeSize : cfg.maxLoginSize;
            if (len > stageLimit) {
                return strikeAndKill(ctx, "frame #" + frameIndex + " " + len + " byte > limit " + stageLimit);
            }
            frameLen = (int) len;
            frameRemaining = frameLen;
            if (frameRemaining == 0) frameDone(now);
        }
        return true;
    }

    private void frameDone(long now) {
        frameIndex++;
        lastProgressMs = now;
        if (frameIndex >= MAX_PARSED_FRAMES) stopParsing();
    }

    private void stopParsing() {
        parsing = false;
        cancelWatchdog();
        if (preLoginCounted) {
            tracker.preLoginGlobal.decrementAndGet();
            preLoginCounted = false;
        }
    }

    // ------------------------------------------------------------------ slowloris watchdog

    private void watchdogTick(ChannelHandlerContext ctx) {
        if (closed || !parsing || !ctx.channel().isActive()) {
            cancelWatchdog();
            return;
        }
        long now = System.currentTimeMillis();
        boolean inFrame = frameRemaining > 0 || lenBytes > 0;
        if (inFrame) {
            if (now - frameStartMs > cfg.frameTimeoutMs) {
                strikeAndKill(ctx, "slowloris: frame tidak lengkap dalam " + cfg.frameTimeoutMs + "ms");
            }
        } else {
            long limit = (frameIndex <= 1) ? cfg.firstPacketTimeoutMs : cfg.preLoginTotalTimeoutMs;
            if (now - lastProgressMs > limit) {
                strikeAndKill(ctx, "slowloris: tidak ada paket (frame #" + frameIndex + ") dalam " + limit + "ms");
            }
        }
    }

    private void cancelWatchdog() {
        if (watchdog != null) {
            watchdog.cancel(false);
            watchdog = null;
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Backpressure: berhenti membaca socket sampai window 1 detik habis. Tidak ada byte yang dibuang. */
    private void throttle(final ChannelHandlerContext ctx, long now) {
        if (throttled || !ctx.channel().config().isAutoRead()) return;
        throttled = true;
        long wait = Math.max(1L, 1000L - (now - ipState.windowStart.get()));
        ctx.channel().config().setAutoRead(false);
        ctx.executor().schedule(new Runnable() {
            @Override
            public void run() {
                throttled = false;
                if (!closed && ctx.channel().isActive()) ctx.channel().config().setAutoRead(true);
            }
        }, wait, TimeUnit.MILLISECONDS);
    }

    private void forwardActive(ChannelHandlerContext ctx) {
        activeForwarded = true;
        ctx.fireChannelActive();
    }

    private boolean strikeAndKill(ChannelHandlerContext ctx, String reason) {
        tracker.strike(ip, reason);
        kill(ctx);
        return false;
    }

    private boolean banAndKill(ChannelHandlerContext ctx, String reason) {
        tracker.ban(ip, cfg.oversizeBanMs, reason);
        kill(ctx);
        return false;
    }

    private void kill(ChannelHandlerContext ctx) {
        if (closed) return;
        closed = true;
        cancelWatchdog();
        ctx.channel().config().setAutoRead(false);
        ctx.close();
    }
}
